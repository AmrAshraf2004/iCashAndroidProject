package com.example.icash;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import androidx.work.Configuration;
import androidx.work.WorkManager;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.splashscreen);

        // Delay logic using a Handler
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Start WelcomeActivity after 3 seconds
                Intent intent = new Intent(MainActivity.this, WelcomeActivity.class);

                startActivity(intent);
                finish(); // Optional: Call finish() if you want to close MainActivity
            }
        }, 3000); // 3000 milliseconds = 3 seconds
    }
}