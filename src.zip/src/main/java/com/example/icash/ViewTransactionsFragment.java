package com.example.icash;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.icash.R;
import com.example.icash.databinding.FragmentViewTransactionsBinding;
import com.example.icash.models.FirebaseHandler;
import com.example.icash.models.SessionManager;
import com.example.icash.models.Transaction;

import java.util.ArrayList;
import java.util.List;

public class ViewTransactionsFragment extends Fragment {

    private FragmentViewTransactionsBinding binding;
    private FirebaseHandler firebaseHandler;
    private SessionManager sessionManager;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentViewTransactionsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        firebaseHandler = FirebaseHandler.getInstance();
        sessionManager = SessionManager.getInstance();

        loadTransactions();
    }

    private void loadTransactions() {
        String userId = sessionManager.getCurrentUser().getUserId();

        firebaseHandler.fetchTransactionsByUserId(userId, transactions -> {
            if (transactions != null) {
                List<Transaction> sentTransactions = new ArrayList<>();
                List<Transaction> receivedTransactions = new ArrayList<>();

                for (Transaction transaction : transactions) {
                    if (transaction.getSenderUserId().equals(userId)) {
                        sentTransactions.add(transaction);
                    } else if (transaction.getRecipientUserId().equals(userId)) {
                        receivedTransactions.add(transaction);
                    }
                }

                displayTransactions(binding.sentTransactionsContainer, sentTransactions);
                displayTransactions(binding.receivedTransactionsContainer, receivedTransactions);
            } else {
                Toast.makeText(requireContext(), "No transactions found.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void displayTransactions(LinearLayout container, List<Transaction> transactions) {
        container.removeAllViews(); // Clear existing views

        for (Transaction transaction : transactions) {
            View transactionView = LayoutInflater.from(requireContext()).inflate(R.layout.item_transaction, container, false);

            TextView transactionId = transactionView.findViewById(R.id.transaction_id);
            TextView transactionType = transactionView.findViewById(R.id.transaction_type);
            TextView transactionAmount = transactionView.findViewById(R.id.transaction_amount);
            TextView transactionDate = transactionView.findViewById(R.id.transaction_date);
            TextView transactionSender = transactionView.findViewById(R.id.transaction_sender);
            TextView transactionReceiver = transactionView.findViewById(R.id.transaction_receiver);
            TextView transactionStatus = transactionView.findViewById(R.id.transaction_status);
            TextView transactionDescription = transactionView.findViewById(R.id.transaction_description);

            transactionId.setText(transaction.getTransactionId());
            transactionType.setText(transaction.getType());
            transactionAmount.setText(String.format("$%.2f", transaction.getAmount()));
            transactionDate.setText(transaction.getDate().toString());
            transactionSender.setText("Sender: " + transaction.getSenderAccount());
            transactionStatus.setText("Status: " + transaction.getStatus());
            transactionDescription.setText("Description: " + transaction.getDescription());

            // Fetch and display the recipient's account number
            String recipientUserId = transaction.getRecipientUserId();
            if (recipientUserId != null) {
                firebaseHandler.getUserAccountNumber(recipientUserId, accountNumber -> {
                    if (accountNumber != null) {
                        transactionReceiver.setText("Receiver: " + accountNumber);
                    } else {
                        transactionReceiver.setText("Receiver: Unknown");
                    }
                });
            } else {
                transactionReceiver.setText("Receiver: N/A");
            }

            container.addView(transactionView);
        }
    }



    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
