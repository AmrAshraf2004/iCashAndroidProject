package com.example.icash;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.icash.R;
import com.example.icash.databinding.FragmentSendFundsBinding;
import com.example.icash.models.FirebaseHandler;
import com.example.icash.models.SessionManager;
import com.example.icash.models.Transaction;
import com.example.icash.models.User;

import java.util.Date;
import java.util.UUID;

public class SendFundsFragment extends Fragment {

    private FragmentSendFundsBinding binding;
    private FirebaseHandler firebaseHandler;
    private SessionManager sessionManager;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSendFundsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        firebaseHandler = FirebaseHandler.getInstance();
        sessionManager = SessionManager.getInstance();

        setupSenderBalance();

        binding.sendFundsButton.setOnClickListener(v -> handleSendFunds());
    }

    private void setupSenderBalance() {
        User currentUser = sessionManager.getCurrentUser();
        if (currentUser != null) {
            binding.senderBalanceValue.setText(String.format("$%.2f", currentUser.getBalance()));
        } else {
            binding.senderBalanceValue.setText("$0.00");
        }
    }

    private void handleSendFunds() {
        String recipientAccount = binding.recipientAccountInput.getText().toString().trim();
        String amountStr = binding.amountInput.getText().toString().trim();

        if (TextUtils.isEmpty(recipientAccount)) {
            showToast("Please enter recipient account.");
            return;
        }

        if (TextUtils.isEmpty(amountStr)) {
            showToast("Please enter an amount.");
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (NumberFormatException e) {
            showToast("Invalid amount entered.");
            return;
        }

        if (amount <= 0) {
            showToast("Amount must be greater than zero.");
            return;
        }

        User currentUser = sessionManager.getCurrentUser();
        if (currentUser == null) {
            showToast("User not logged in.");
            return;
        }

        if (amount > currentUser.getBalance()) {
            showToast("Insufficient balance.");
            return;
        }

        // Validate recipient account and get recipient's balance
        firebaseHandler.getUserDetailsByAccountNumber(recipientAccount, recipientDetails -> {
            if (recipientDetails == null) {
                showToast("Recipient account not found.");
            } else {
                String recipientUserId = recipientDetails.first;

                // Deduct from sender
                double updatedSenderBalance = currentUser.getBalance() - amount;
                firebaseHandler.updateUserBalance(currentUser.getUserId(), updatedSenderBalance, senderSuccess -> {
                    if (!senderSuccess) {
                        showToast("Failed to update sender's balance.");
                        return;
                    }

                    // Update the sender's balance in SessionManager
                    currentUser.setBalance(updatedSenderBalance);
                    sessionManager.setCurrentUser(currentUser);
                    setupSenderBalance();

                    // Fetch recipient's balance
                    firebaseHandler.getUserBalance(recipientUserId, recipientBalance -> {
                        if (recipientBalance == null) {
                            showToast("Failed to fetch recipient's balance.");
                            return;
                        }

                        // Add the amount to the recipient's balance
                        double updatedRecipientBalance = recipientBalance + amount;
                        firebaseHandler.updateUserBalance(recipientUserId, updatedRecipientBalance, recipientSuccess -> {
                            if (!recipientSuccess) {
                                showToast("Failed to update recipient's balance.");
                            } else {
                                // Save transaction
                                Transaction transaction = new Transaction(
                                        UUID.randomUUID().toString(),
                                        "Send",
                                        amount,
                                        new Date(),
                                        currentUser.getUserId(),
                                        currentUser.getAccountNumber(),
                                        recipientUserId,
                                        recipientAccount,
                                        "Completed",
                                        "Send of $" + amount
                                );

                                firebaseHandler.saveTransaction(transaction, success -> {
                                    if (success) {
                                        showToast("Funds sent successfully!");
                                        binding.recipientAccountInput.setText("");
                                        binding.amountInput.setText("");
                                    } else {
                                        showToast("Failed to save transaction.");
                                    }
                                });
                            }
                        });
                    });
                });
            }
        });
    }




    private void showToast(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
