package com.example.icash.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import com.example.icash.R;
import com.example.icash.databinding.FragmentHomeBinding;
import com.example.icash.models.SessionManager;
import com.example.icash.models.User;
import com.example.icash.notifications.NotificationWorker;

public class HomeFragment extends Fragment {

    private static boolean isNotificationShown = false;
    private FragmentHomeBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Set user details
        setupUserDetails();

        // Set up button actions
        binding.quickDepositButton.setOnClickListener(v ->
                Navigation.findNavController(view).navigate(R.id.nav_deposit_withdraw)
        );

        binding.quickWithdrawButton.setOnClickListener(v ->
                Navigation.findNavController(view).navigate(R.id.nav_deposit_withdraw)
        );

        binding.quickSendButton.setOnClickListener(v ->
                Navigation.findNavController(view).navigate(R.id.nav_send_funds)
        );

        // Trigger the notification worker once
        if (!isNotificationShown) {
            setupNotificationWorker();
            isNotificationShown = true;
        }
    }

    private void setupUserDetails() {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser != null) {
            String welcomeMessage = "Welcome, " + currentUser.getFirstName() + "!";
            String balanceMessage = "$" + String.format("%.2f", currentUser.getBalance());
            binding.welcomeText.setText(welcomeMessage);
            binding.balanceText.setText(balanceMessage);
        } else {
            binding.welcomeText.setText("Welcome, Guest!");
            binding.balanceText.setText("$0.00");
        }
    }

    private void setupNotificationWorker() {
        OneTimeWorkRequest notificationWork = new OneTimeWorkRequest.Builder(NotificationWorker.class).build();
        WorkManager.getInstance(requireContext()).enqueue(notificationWork);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
