package com.example.icash;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.icash.R;
import com.example.icash.databinding.FragmentDepositWithdrawBinding;
import com.example.icash.models.Card;
import com.example.icash.models.FirebaseHandler;
import com.example.icash.models.SessionManager;
import com.example.icash.models.Transaction;
import com.example.icash.models.User;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class DepositWithdrawFragment extends Fragment {

    private FragmentDepositWithdrawBinding binding;
    private FirebaseHandler firebaseHandler;
    private SessionManager sessionManager;
    private List<Card> userCards;
    private ArrayAdapter<String> cardAdapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentDepositWithdrawBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        firebaseHandler = FirebaseHandler.getInstance();
        sessionManager = SessionManager.getInstance();

        // Load wallet balance and cards
        setupWalletBalance();
        loadUserCards();

        // Set button listeners
        binding.depositButton.setOnClickListener(v -> handleTransaction("Deposit"));
        binding.withdrawButton.setOnClickListener(v -> handleTransaction("Withdraw"));
    }

    private void setupWalletBalance() {
        User currentUser = sessionManager.getCurrentUser();
        if (currentUser != null) {
            binding.walletBalanceValue.setText(String.format("$%.2f", currentUser.getBalance()));
        } else {
            binding.walletBalanceValue.setText("$0.00");
        }
    }

    private void loadUserCards() {
        String userId = sessionManager.getCurrentUser().getUserId();
        firebaseHandler.fetchUserCards(userId, cards -> {
            userCards = cards;
            List<String> cardNumbers = new ArrayList<>();
            for (Card card : cards) {
                cardNumbers.add(card.getCardNumber());
            }
            cardAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, cardNumbers);
            cardAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            binding.cardSpinner.setAdapter(cardAdapter);
        });
    }

    private void handleTransaction(String type) {
        String selectedCard = (String) binding.cardSpinner.getSelectedItem();
        String amountStr = binding.amountInput.getText().toString().trim();

        if (TextUtils.isEmpty(selectedCard)) {
            Toast.makeText(requireContext(), "Please select a card", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(amountStr)) {
            Toast.makeText(requireContext(), "Please enter an amount", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount = Double.parseDouble(amountStr);

        User currentUser = sessionManager.getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(requireContext(), "User not logged in.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (type.equals("Withdraw") && amount > currentUser.getBalance()) {
            Toast.makeText(requireContext(), "Insufficient wallet balance", Toast.LENGTH_SHORT).show();
            return;
        }

        // Update wallet balance
        double updatedBalance = type.equals("Withdraw") ? currentUser.getBalance() - amount : currentUser.getBalance() + amount;
        currentUser.setBalance(updatedBalance);
        sessionManager.setCurrentUser(currentUser);

        // Persist updated balance to Firebase using FirebaseHandler
        firebaseHandler.updateUserBalance(currentUser.getUserId(), updatedBalance, success -> {
            if (!success) {
                Toast.makeText(requireContext(), "Failed to update balance in the database.", Toast.LENGTH_SHORT).show();
            }
        });

        setupWalletBalance();

        // Save transaction
        String senderUserId = currentUser.getUserId();
        String receiverUserId = type.equals("Withdraw") ? null : senderUserId; // For deposits and withdrawals, receiver is the same
        String senderAccount = currentUser.getAccountNumber();
        String receiverAccount = type.equals("Withdraw") ? null : senderAccount;

        saveTransaction(type, amount, senderUserId, receiverUserId, senderAccount, receiverAccount);

        Toast.makeText(requireContext(), type + " successful!", Toast.LENGTH_SHORT).show();
        binding.amountInput.setText("");
    }



    private void saveTransaction(String type, double amount, String senderUserId, String receiverUserId, String senderAccount, String receiverAccount) {
        String transactionId = UUID.randomUUID().toString();
        Date date = new Date();
        String status = "Completed";
        String description = type + " of $" + amount;

        // Create the transaction object with the correct constructor
        Transaction transaction = new Transaction(
                transactionId,
                type,
                amount,
                date,
                senderUserId,
                receiverUserId,
                senderAccount,
                receiverAccount,
                status,
                description
        );

        // Save the transaction using FirebaseHandler
        firebaseHandler.saveTransaction(transaction, success -> {
            if (!success) {
                Toast.makeText(requireContext(), "Failed to save transaction", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(requireContext(), "Transaction saved successfully!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
