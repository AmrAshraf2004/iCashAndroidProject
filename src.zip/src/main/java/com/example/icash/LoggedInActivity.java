package com.example.icash;

import static androidx.core.content.ContentProviderCompat.requireContext;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.work.Configuration;
import androidx.work.Constraints;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;


import com.example.icash.databinding.LoggedinscreenBinding;
import com.example.icash.models.FirebaseHandler;
import com.example.icash.models.SessionManager;
import com.example.icash.models.User;
import com.example.icash.notifications.NotificationWorker;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseUser;

public class LoggedInActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    private LoggedinscreenBinding binding;



    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);

        binding = LoggedinscreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarLoggedIn.toolbar);

        // Set up Floating Action Button
        binding.appBarLoggedIn.fab.setOnClickListener(view -> handleLogout());

        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;

        // Configure Navigation
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_deposit_withdraw, R.id.nav_send_funds, R.id.nav_view_transactions, R.id.nav_manage_account)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_logged_in);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        // Set up user details in Navigation Header
        setupNavigationHeader(navigationView);


    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_logged_in);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration) || super.onSupportNavigateUp();
    }

    private void setupNavigationHeader(NavigationView navigationView) {
        View headerView = navigationView.getHeaderView(0);

        // Get TextViews from the navigation header
        TextView userName = headerView.findViewById(R.id.nav_header_title);
        TextView userEmail = headerView.findViewById(R.id.textView);

        // Get user details from SessionManager
        SessionManager sessionManager = SessionManager.getInstance();

        User currentUser = sessionManager.getCurrentUser();

        if (currentUser != null) {
            // Set user name and email
            userName.setText(currentUser.getFirstName() + " " + currentUser.getLastName());
            userEmail.setText(currentUser.getEmail());
        } else {
            // Default fallback if session data is missing
            userName.setText("Guest");
            userEmail.setText("");
        }
    }

    private void handleLogout() {
        // Clear session data
        SessionManager sessionManager = SessionManager.getInstance();
        sessionManager.clearSession();

        FirebaseHandler firebaseHandler = FirebaseHandler.getInstance();
        firebaseHandler.logOut();

        // Navigate back to LoginActivity
        Intent intent = new Intent(LoggedInActivity.this, LoginActivity.class);
        startActivity(intent);
        finish(); // Close current activity
    }


}
