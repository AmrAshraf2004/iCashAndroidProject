package com.example.icash;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.icash.models.FirebaseHandler;
import com.example.icash.models.User;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseUser;

public class SignupActivity extends AppCompatActivity {

    private EditText firstNameInput, lastNameInput, emailInput, passwordInput, confirmPasswordInput;
    private MaterialButton signupButton;
    private ImageButton togglePasswordButton, toggleConfirmPasswordButton;

    private Button goToLoginButton;

    private boolean isPasswordVisible = false, isConfirmPasswordVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signupscreen);

        // Initialize UI components
        firstNameInput = findViewById(R.id.edit_first_name_signup);
        lastNameInput = findViewById(R.id.edit_last_name_signup);
        emailInput = findViewById(R.id.edit_email_address_signup);
        passwordInput = findViewById(R.id.edit_password_signup);
        confirmPasswordInput = findViewById(R.id.edit_password_confirmation_signup);
        signupButton = findViewById(R.id.signup_start);
        togglePasswordButton = findViewById(R.id.show_hide_password_signup);
        toggleConfirmPasswordButton = findViewById(R.id.show_hide_password_confirmation_signup);
        goToLoginButton = findViewById(R.id.go_to_login);

        // Set up password visibility toggles
        togglePasswordButton.setOnClickListener(v -> togglePasswordVisibility(passwordInput, togglePasswordButton));
        toggleConfirmPasswordButton.setOnClickListener(v -> togglePasswordVisibility(confirmPasswordInput, toggleConfirmPasswordButton));

        // Set up the signup button
        signupButton.setOnClickListener(v -> handleSignup());

        // Navigate to LoginActivity
        goToLoginButton.setOnClickListener(v -> navigateToLogin());


    }

    private void togglePasswordVisibility(EditText passwordField, ImageButton toggleButton) {
        if (passwordField.getTransformationMethod() != null) {
            // Show password
            passwordField.setTransformationMethod(null);
            toggleButton.setImageResource(R.drawable.hidepassword); // Change to your "hide password" icon
        } else {
            // Hide password
            passwordField.setTransformationMethod(new android.text.method.PasswordTransformationMethod());
            toggleButton.setImageResource(R.drawable.showpassword); // Change to your "show password" icon
        }
        passwordField.setSelection(passwordField.getText().length()); // Keep cursor at the end
    }

    private void handleSignup() {
        String firstName = firstNameInput.getText().toString().trim();
        String lastName = lastNameInput.getText().toString().trim();
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();
        String confirmPassword = confirmPasswordInput.getText().toString().trim();

        // Validate inputs
        if (TextUtils.isEmpty(firstName)) {
            firstNameInput.setError("First name is required");
            return;
        }
        if (TextUtils.isEmpty(lastName)) {
            lastNameInput.setError("Last name is required");
            return;
        }
        if (TextUtils.isEmpty(email)) {
            emailInput.setError("Email is required");
            return;
        }
        if (!isValidEmail(email)) {
            emailInput.setError("Enter a valid email address");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            passwordInput.setError("Password is required");
            return;
        }
        if (!isValidPassword(password)) {
            passwordInput.setError("Password must contain at least 8 characters, 1 uppercase, 1 lowercase, 1 digit, and 1 special character");
            return;
        }
        if (!password.equals(confirmPassword)) {
            confirmPasswordInput.setError("Passwords do not match");
            return;
        }

        FirebaseHandler firebaseHandler = FirebaseHandler.getInstance();

        // Sign up user using FirebaseHandler
        firebaseHandler.signUp(email, password, isSuccess -> {
            if (isSuccess) {
                FirebaseUser firebaseUser = firebaseHandler.getCurrentUser();
                if (firebaseUser != null) {
                    // Create and add the new user
                    User newUser = new User(firstName, lastName, email);
                    firebaseHandler.addUser(firebaseUser.getUid(), newUser);

                    // Send email verification
                    firebaseUser.sendEmailVerification()
                            .addOnCompleteListener(task -> {
                                if (task.isSuccessful()) {
                                    showToast("Signup successful! Verify your email.");
                                } else {
                                    showToast("Signup successful, but failed to send verification email.");
                                }
                            });

                    // Navigate to LoginActivity
                    navigateToLogin();
                }
            } else {
                showToast("Signup failed. Please try again.");
            }
        });
    }


    private void navigateToLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private boolean isValidEmail(String email) {
        String emailPattern = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        return email.matches(emailPattern);
    }

    private boolean isValidPassword(String password) {
        String passwordPattern = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$";
        return password.matches(passwordPattern);
    }
}
