package com.example.icash;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.icash.models.Card;
import com.example.icash.models.FirebaseHandler;
import com.example.icash.models.SessionManager;
import com.example.icash.models.User;

public class AccountFragment extends Fragment {

    private TextView userNameTextView, userEmailTextView, accountNumberTextView;
    private EditText editCardNumber, editCardExpiry, editCardCvv, editRemoveCardNumber;
    private Button addCardButton, removeCardButton, logoutButton;

    private FirebaseHandler firebaseHandler;
    private SessionManager sessionManager;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_account, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize UI components
        userNameTextView = view.findViewById(R.id.user_name_label);
        userEmailTextView = view.findViewById(R.id.user_email_label);
        accountNumberTextView = view.findViewById(R.id.account_number_label);

        editCardNumber = view.findViewById(R.id.edit_card_number);
        editCardExpiry = view.findViewById(R.id.edit_card_expiry);
        editCardCvv = view.findViewById(R.id.edit_card_cvv);
        editRemoveCardNumber = view.findViewById(R.id.edit_remove_card_number);

        addCardButton = view.findViewById(R.id.add_card_button);
        removeCardButton = view.findViewById(R.id.remove_card_button);
        logoutButton = view.findViewById(R.id.logout_button);

        // Initialize FirebaseHandler and SessionManager
        firebaseHandler = FirebaseHandler.getInstance();
        sessionManager = SessionManager.getInstance();

        // Set up user details
        setupUserDetails();

        // Set up button listeners
        addCardButton.setOnClickListener(v -> handleAddCard());
        removeCardButton.setOnClickListener(v -> handleRemoveCard());
        logoutButton.setOnClickListener(v -> handleLogout());
    }

    private void handleLogout() {
        // Clear session data
        sessionManager.clearSession();

        firebaseHandler.logOut();

        // Navigate back to LoginActivity
        if (getActivity() != null) {
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            startActivity(intent);
            getActivity().finish();
        } else {
            showToast("Failed to logout. Please try again.");
        }
    }

    private void setupUserDetails() {
        User currentUser = sessionManager.getCurrentUser();
        if (currentUser != null) {
            userNameTextView.setText("Name: " + currentUser.getFirstName() + " " + currentUser.getLastName());
            userEmailTextView.setText("Email: " + currentUser.getEmail());
            accountNumberTextView.setText("Account Number: " + currentUser.getAccountNumber());
        } else {
            showToast("Failed to load user details.");
        }
    }

    private void handleAddCard() {
        String cardNumber = editCardNumber.getText().toString().trim();
        String expiryDate = editCardExpiry.getText().toString().trim();
        String cvv = editCardCvv.getText().toString().trim();

        // Validate card number
        if (!isValidCardNumber(cardNumber)) {
            showToast("Invalid card number. Must be 16 digits.");
            return;
        }

        // Validate expiry date
        if (!isValidExpiryDate(expiryDate)) {
            showToast("Invalid expiry date. Use MM/YY format.");
            return;
        }

        // Validate CVV
        if (!isValidCvv(cvv)) {
            showToast("Invalid CVV. Must be 3 digits.");
            return;
        }

        // Get userId and accountNumber
        String userId = sessionManager.getCurrentUser().getUserId();
        String accountNumber = sessionManager.getCurrentUser().getAccountNumber();

        if (userId == null || userId.isEmpty() || accountNumber == null || accountNumber.isEmpty()) {
            showToast("User ID or account number is missing. Cannot add card.");
            return;
        }

        // Create a new card object with userId and accountNumber
        Card newCard = new Card(userId, accountNumber, cardNumber, expiryDate, cvv);

        // Add the card using FirebaseHandler
        firebaseHandler.addCard(userId, newCard, success -> {
            if (success) {
                showToast("Card added successfully!");
                editCardNumber.setText("");
                editCardExpiry.setText("");
                editCardCvv.setText("");
            } else {
                showToast("Failed to add card.");
            }
        });
    }



    private void handleRemoveCard() {
        String cardNumberToRemove = editRemoveCardNumber.getText().toString().trim();

        if (TextUtils.isEmpty(cardNumberToRemove)) {
            showToast("Please enter a card number.");
            return;
        }

        User currentUser = sessionManager.getCurrentUser();
        if (currentUser == null) {
            showToast("User not logged in.");
            return;
        }

        String userId = currentUser.getUserId();

        firebaseHandler.fetchCardKeyToRemove(userId, cardNumberToRemove, cardKeyToRemove -> {
            if (cardKeyToRemove != null) {
                firebaseHandler.removeCard(userId, cardKeyToRemove, isSuccess -> {
                    if (isSuccess) {
                        showToast("Card removed successfully!");
                        editRemoveCardNumber.setText("");
                    } else {
                        showToast("Failed to remove card.");
                    }
                });
            } else {
                showToast("Card not found. Please check the card number.");
            }
        });
    }





    private boolean isValidCardNumber(String cardNumber) {
        return cardNumber.matches("\\d{16}");
    }

    private boolean isValidExpiryDate(String expiryDate) {
        return expiryDate.matches("^(0[1-9]|1[0-2])/([0-9]{2})$");
    }


    private boolean isValidCvv(String cvv) {
        return cvv.matches("\\d{3}");
    }

    private void showToast(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }
}
