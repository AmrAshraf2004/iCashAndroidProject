package com.example.icash;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.icash.models.Callback;
import com.example.icash.models.Card;
import com.example.icash.models.FirebaseCallback;
import com.example.icash.models.FirebaseHandler;
import com.example.icash.models.SessionManager;
import com.example.icash.models.Transaction;
import com.example.icash.models.User;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends AppCompatActivity {

    private EditText emailInputField, passwordInputField;
    private MaterialButton loginButton;
    private ImageButton togglePasswordButton;
    private TextView goToSignup, goToResetPasswordButton;
    private boolean isPasswordVisible = false;

    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loginscreen);

        // Initialize UI components
        emailInputField = findViewById(R.id.edit_email_address_login);
        passwordInputField = findViewById(R.id.edit_password_login);
        loginButton = findViewById(R.id.login_start);
        togglePasswordButton = findViewById(R.id.show_hide_password_login);
        goToSignup = findViewById(R.id.go_to_signup);
        goToResetPasswordButton = findViewById(R.id.go_to_reset_password_button);

        firebaseAuth = FirebaseAuth.getInstance();

        // Set up password visibility toggle
        togglePasswordButton.setOnClickListener(v -> togglePasswordVisibility());

        // Set up login button click listener
        loginButton.setOnClickListener(v -> handleLogin());

        // Navigate to SignupActivity
        goToSignup.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
            startActivity(intent);
        });

        // Navigate to ResetPasswordActivity
        goToResetPasswordButton.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, ResetPasswordActivity.class);
            startActivity(intent);
        });
    }

    private void togglePasswordVisibility() {
        if (isPasswordVisible) {
            passwordInputField.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
            passwordInputField.setSelection(passwordInputField.getText().length());
            togglePasswordButton.setImageResource(R.drawable.showpassword);
        } else {
            passwordInputField.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
            passwordInputField.setSelection(passwordInputField.getText().length());
            togglePasswordButton.setImageResource(R.drawable.hidepassword);
        }
        isPasswordVisible = !isPasswordVisible;
    }

    private void handleLogin() {
        String email = emailInputField.getText().toString().trim();
        String password = passwordInputField.getText().toString().trim();

        // Validate email
        if (TextUtils.isEmpty(email)) {
            emailInputField.setError("Email is required");
            return;
        }
        if (!isValidEmail(email)) {
            emailInputField.setError("Enter a valid email address");
            return;
        }

        // Validate password
        if (TextUtils.isEmpty(password)) {
            passwordInputField.setError("Password is required");
            return;
        }

        FirebaseHandler firebaseHandler = FirebaseHandler.getInstance();

        firebaseHandler.logIn(email, password, new Callback<Boolean>() {
            @Override
            public void onComplete(Boolean isSuccess) {
                if (isSuccess) {
                    FirebaseUser firebaseUser = firebaseHandler.getCurrentUser();
                    if (firebaseUser != null) {
                        if (firebaseUser.isEmailVerified()) {
                            String userId = firebaseUser.getUid();
                            setupData(userId, new Callback<Boolean>() {
                                @Override
                                public void onComplete(Boolean setupSuccess) {
                                    if (setupSuccess) {
                                        navigateToLoggedIn();
                                    } else {
                                        showToast("Failed to set up user data.");

                                    }
                                }
                            });
                        } else {
                            showToast("Please verify your email before logging in.");
                            firebaseHandler.logOut();
                        }
                    } else {
                        showToast("User not found.");
                    }
                } else {
                    showToast("Login failed: Check email or password.");
                }
            }
        });
    }



    private void setupData(String userId, Callback<Boolean> callback) {
        FirebaseHandler firebaseHandler = FirebaseHandler.getInstance();
        SessionManager sessionManager = SessionManager.getInstance();

        firebaseHandler.fetchUser(userId, new Callback<User>() {
            @Override
            public void onComplete(User user) {
                if (user != null) {
                    user.setUserId(userId); // Set the userId in the User object
                    sessionManager.setCurrentUser(user);

                    // Fetch user cards
                    firebaseHandler.fetchUserCards(userId, new Callback<List<Card>>() {
                        @Override
                        public void onComplete(List<Card> cards) {
                            sessionManager.setUserCards(cards);

                            // Fetch user transactions
                            firebaseHandler.fetchUserTransactions(userId, new Callback<List<Transaction>>() {
                                @Override
                                public void onComplete(List<Transaction> transactions) {
                                    sessionManager.setUserTransactions(transactions);
                                    callback.onComplete(true); // Setup successful
                                }
                            });
                        }
                    });
                } else {
                    callback.onComplete(false); // Setup failed
                }
            }
        });
    }








    private void navigateToLoggedIn() {
        Intent intent = new Intent(LoginActivity.this, LoggedInActivity.class);
        startActivity(intent);
        finish();
    }


    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private boolean isValidEmail(String email) {
        String emailPattern = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        return email.matches(emailPattern);
    }

    private boolean isValidPassword(String password) {
        String passwordPattern = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$";
        return password.matches(passwordPattern);
    }
}
