package com.example.icash.models;

import java.util.ArrayList;
import java.util.List;

public class SessionManager {

    private static SessionManager instance;
    private User currentUser;
    private List<Card> userCards;
    private List<Transaction> userTransactions;

    private SessionManager() {
        this.userCards = new ArrayList<>();
        this.userTransactions = new ArrayList<>();
    }

    public static synchronized SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setUserCards(List<Card> cards) {
        this.userCards = cards;
    }

    public List<Card> getUserCards() {
        return userCards;
    }

    public void setUserTransactions(List<Transaction> transactions) {
        this.userTransactions = transactions;
    }

    public List<Transaction> getUserTransactions() {
        return userTransactions;
    }

    public void clearSession() {
        currentUser = null;
        userCards.clear();
        userTransactions.clear();
    }
}
