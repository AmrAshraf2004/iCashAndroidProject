package com.example.icash.models;

import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;

import androidx.annotation.NonNull;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class FirebaseHandler {

    private static FirebaseHandler instance;
    private final FirebaseAuth firebaseAuth;
    private final DatabaseReference databaseReference;

    // Private constructor for Singleton pattern
    private FirebaseHandler() {
        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance("https://icashproject-default-rtdb.firebaseio.com/").getReference();
    }

    // Singleton instance getter
    public static synchronized FirebaseHandler getInstance() {
        if (instance == null) {
            instance = new FirebaseHandler();
        }
        return instance;
    }

    public void addUser(String userId, User user) {
        if (userId == null || user == null) {
            System.err.println("Error: User ID or User object is null.");
            return;
        }

        if (databaseReference == null) {
            System.err.println("Error: Database reference is null.");
            return;
        }

        databaseReference.child("users").child(userId).setValue(user)
                .addOnSuccessListener(aVoid -> System.out.println("User added successfully for ID: " + userId))
                .addOnFailureListener(e -> System.err.println("Failed to add user: " + e.getMessage()));
    }

    public void signUp(String email, String password, Callback<Boolean> callback) {
        if (firebaseAuth == null) {
            System.err.println("Error: FirebaseAuth is not initialized.");
            callback.onComplete(false);
            return;
        }

        if (email == null || email.isEmpty() || password == null || password.isEmpty()) {
            System.err.println("Error: Email or password is invalid.");
            callback.onComplete(false);
            return;
        }

        firebaseAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        System.out.println("Sign-up successful for email: " + email);
                        callback.onComplete(true);
                    } else {
                        if (task.getException() != null) {
                            System.err.println("Sign-up error: " + task.getException().getMessage());
                        }
                        callback.onComplete(false);
                    }
                })
                .addOnFailureListener(e -> {
                    System.err.println("Sign-up failed: " + e.getMessage());
                    callback.onComplete(false);
                });
    }



    // Log in a user
    public void logIn(String email, String password, Callback<Boolean> callback) {
        firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> callback.onComplete(task.isSuccessful()));
    }

    // Log out the current user
    public void logOut() {
        firebaseAuth.signOut();
    }

    // Fetch user details
    public void fetchUser(String userId, Callback<User> callback) {
        databaseReference.child("users").child(userId).get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.exists()) {
                        User user = snapshot.getValue(User.class);
                        callback.onComplete(user);
                    } else {
                        callback.onComplete(null);
                    }
                })
                .addOnFailureListener(e -> callback.onComplete(null));
    }

    // Update user's balance in Firebase
    public void updateUserBalance(String userId, double balance, Callback<Boolean> callback) {
        if (userId == null) {
            callback.onComplete(false);
            return;
        }

        databaseReference.child("users").child(userId).child("balance").setValue(balance)
                .addOnSuccessListener(aVoid -> callback.onComplete(true))
                .addOnFailureListener(e -> callback.onComplete(false));
    }


    // Fetch user balance from the database
    public void getUserBalance(String userId, Callback<Double> callback) {
        if (userId == null) {
            callback.onComplete(null); // Return null if userId is invalid
            return;
        }

        databaseReference.child("users").child(userId).child("balance").get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.exists()) {
                        try {
                            Double balance = snapshot.getValue(Double.class);
                            callback.onComplete(balance != null ? balance : 0.0); // Default to 0.0 if balance is null
                        } catch (Exception e) {
                            callback.onComplete(0.0); // Handle potential parsing errors
                        }
                    } else {
                        callback.onComplete(0.0); // Return 0.0 if balance doesn't exist
                    }
                })
                .addOnFailureListener(e -> callback.onComplete(null)); // Return null on failure
    }



    public void fetchTransactionsByUserId(String userId, Callback<List<Transaction>> callback) {
        if (userId == null) {
            callback.onComplete(null);
            return;
        }

        databaseReference.child("transactions").get()
                .addOnSuccessListener(snapshot -> {
                    List<Transaction> transactions = new ArrayList<>();
                    for (DataSnapshot transactionSnapshot : snapshot.getChildren()) {
                        Transaction transaction = transactionSnapshot.getValue(Transaction.class);
                        if (transaction != null && (transaction.getSenderUserId().equals(userId) || transaction.getRecipientUserId().equals(userId))) {
                            transactions.add(transaction);
                        }
                    }
                    callback.onComplete(transactions);
                })
                .addOnFailureListener(e -> callback.onComplete(null));
    }


    public void getUserDetailsByUserId(String userId, Callback<User> callback) {
        if (userId == null) {
            callback.onComplete(null);
            return;
        }

        databaseReference.child("users").child(userId).get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.exists()) {
                        User user = snapshot.getValue(User.class);
                        callback.onComplete(user);
                    } else {
                        callback.onComplete(null);
                    }
                })
                .addOnFailureListener(e -> callback.onComplete(null));
    }


    public void getUserAccountNumber(String userId, Callback<String> callback) {
        if (userId == null) {
            callback.onComplete(null);
            return;
        }

        databaseReference.child("users").child(userId).child("accountNumber").get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.exists()) {
                        String accountNumber = snapshot.getValue(String.class);
                        callback.onComplete(accountNumber);
                    } else {
                        callback.onComplete(null); // No data found for the given userId
                    }
                })
                .addOnFailureListener(e -> {
                    callback.onComplete(null); // Failed to fetch data
                });
    }



    public void addCard(String userId, Card card, Callback<Boolean> callback) {
        if (userId == null || card == null) {
            callback.onComplete(false);
            return;
        }

        // Check if the card already exists
        databaseReference.child("cards").child(userId)
                .orderByChild("cardNumber").equalTo(card.getCardNumber())
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            // Card already exists
                            callback.onComplete(false);
                            System.out.println("Card already exists.");
                        } else {
                            // Add the card since it doesn't exist
                            databaseReference.child("cards").child(userId).push().setValue(card)
                                    .addOnSuccessListener(aVoid -> {
                                        callback.onComplete(true);
                                        System.out.println("Card added successfully.");
                                    })
                                    .addOnFailureListener(e -> {
                                        callback.onComplete(false);
                                        System.err.println("Failed to add card: " + e.getMessage());
                                    });
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        // Handle the error gracefully
                        callback.onComplete(false);
                        System.err.println("Error checking for duplicate card: " + error.getMessage());
                    }
                });
    }


    // Remove a card using its unique Firebase key
    public void removeCard(String userId, String cardKey, Callback<Boolean> callback) {
        if (userId == null || cardKey == null || cardKey.isEmpty()) {
            callback.onComplete(false);
            return;
        }

        databaseReference.child("cards").child(userId).child(cardKey)
                .removeValue()
                .addOnSuccessListener(aVoid -> callback.onComplete(true))
                .addOnFailureListener(e -> callback.onComplete(false));
    }

    public void fetchCardKeyToRemove(String userId, String cardNumber, Callback<String> callback) {
        if (userId == null || cardNumber == null) {
            callback.onComplete(null);
            return;
        }

        String trimmedCardNumber = cardNumber.trim();

        databaseReference.child("cards").child(userId)
                .orderByChild("cardNumber")
                .equalTo(trimmedCardNumber)
                .get()
                .addOnSuccessListener(snapshot -> {
                    Log.d("DEBUG", "Snapshot exists: " + snapshot.exists());
                    if (snapshot.exists()) {
                        String cardKey = snapshot.getChildren().iterator().next().getKey();
                        callback.onComplete(cardKey);
                    } else {
                        callback.onComplete(null); // No card found
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e("DEBUG", "Error fetching card key: " + e.getMessage());
                    callback.onComplete(null); // Query failed
                });
    }





    // Fetch transactions associated with a user
    public void fetchUserTransactions(String userId, Callback<List<Transaction>> callback) {
        databaseReference.child("transactions").orderByChild("userId").equalTo(userId).get()
                .addOnSuccessListener(snapshot -> {
                    List<Transaction> transactions = new ArrayList<>();
                    for (DataSnapshot transactionSnapshot : snapshot.getChildren()) {
                        Transaction transaction = transactionSnapshot.getValue(Transaction.class);
                        if (transaction != null) {
                            transactions.add(transaction);
                        }
                    }
                    callback.onComplete(transactions);
                })
                .addOnFailureListener(e -> callback.onComplete(new ArrayList<>()));
    }

    // Save a transaction to the database
    public void saveTransaction(Transaction transaction, Callback<Boolean> callback) {
        if (transaction == null) {
            callback.onComplete(false);
            return;
        }

        String transactionId = transaction.getTransactionId();
        if (transactionId == null || transactionId.isEmpty()) {
            transactionId = UUID.randomUUID().toString(); // Generate a unique ID
            transaction.setTransactionId(transactionId);
        }

        databaseReference.child("transactions").child(transactionId).setValue(transaction)
                .addOnSuccessListener(aVoid -> callback.onComplete(true))
                .addOnFailureListener(e -> callback.onComplete(false));
    }


    public void getUserDetailsByAccountNumber(String accountNumber, Callback<Pair<String, String>> callback) {
        if (accountNumber == null || accountNumber.isEmpty()) {
            callback.onComplete(null);
            return;
        }

        databaseReference.child("users")
                .orderByChild("accountNumber")
                .equalTo(accountNumber)
                .get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.exists()) {
                        for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                            String userId = userSnapshot.getKey(); // Firebase key (userId)
                            User user = userSnapshot.getValue(User.class);
                            if (user != null) {
                                // Pair of userId and accountNumber
                                callback.onComplete(new Pair<>(userId, user.getAccountNumber()));
                                return;
                            }
                        }
                    }
                    callback.onComplete(null); // No match found
                })
                .addOnFailureListener(e -> {
                    e.printStackTrace();
                    callback.onComplete(null);
                });
    }



    public void fetchUserCards(String userId, Callback<List<Card>> callback) {
        if (userId == null) {
            callback.onComplete(new ArrayList<>());
            return;
        }

        databaseReference.child("cards").child(userId).get()
                .addOnSuccessListener(snapshot -> {
                    List<Card> cards = new ArrayList<>();
                    for (DataSnapshot cardSnapshot : snapshot.getChildren()) {
                        Card card = cardSnapshot.getValue(Card.class);
                        if (card != null) {
                            card.setCardId(cardSnapshot.getKey()); // Attach the Firebase key to the Card object
                            cards.add(card);
                        }
                    }
                    callback.onComplete(cards);
                })
                .addOnFailureListener(e -> callback.onComplete(new ArrayList<>()));
    }





    // Get the currently logged-in user
    public FirebaseUser getCurrentUser() {
        return firebaseAuth.getCurrentUser();
    }
}
