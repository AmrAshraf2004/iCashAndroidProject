package com.example.icash.models;

public interface Callback<T> {
    void onComplete(T result);
}
