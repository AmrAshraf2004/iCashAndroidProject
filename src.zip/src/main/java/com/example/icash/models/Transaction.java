package com.example.icash.models;

import java.util.Date;

public class Transaction {
    private String transactionId;
    private String type; // e.g., Deposit, Withdraw, Send
    private double amount;
    private Date date;
    private String senderUserId; // User ID of the sender
    private String senderAccount; // Account number of the sender
    private String recipientUserId; // User ID of the recipient
    private String recipientAccount; // Account number of the recipient
    private String status; // Status of the transaction (e.g., Completed, Failed)
    private String description; // Additional description or details about the transaction

    // Empty constructor for Firebase
    public Transaction() {}

    // Parameterized constructor
    public Transaction(String transactionId, String type, double amount, Date date,
                       String senderUserId, String senderAccount, String recipientUserId,
                       String recipientAccount, String status, String description) {
        this.transactionId = transactionId;
        this.type = type;
        this.amount = amount;
        this.date = date;
        this.senderUserId = senderUserId;
        this.senderAccount = senderAccount;
        this.recipientUserId = recipientUserId;
        this.recipientAccount = recipientAccount;
        this.status = status;
        this.description = description;
    }

    // Getters and Setters
    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getSenderUserId() {
        return senderUserId;
    }

    public void setSenderUserId(String senderUserId) {
        this.senderUserId = senderUserId;
    }

    public String getSenderAccount() {
        return senderAccount;
    }

    public void setSenderAccount(String senderAccount) {
        this.senderAccount = senderAccount;
    }

    public String getRecipientUserId() {
        return recipientUserId;
    }

    public void setRecipientUserId(String recipientUserId) {
        this.recipientUserId = recipientUserId;
    }

    public String getRecipientAccount() {
        return recipientAccount;
    }

    public void setRecipientAccount(String recipientAccount) {
        this.recipientAccount = recipientAccount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
