package com.example.icash.models;

public class Card {

    private String cardId; // Firebase key
    private String userId; // Firebase primary key
    private String accountNumber; // Additional field
    private String cardNumber;
    private String expiryDate;
    private String cvv;

    // Constructor
    public Card(String userId, String accountNumber, String cardNumber, String expiryDate, String cvv) {
        this.userId = userId;
        this.accountNumber = accountNumber;
        this.cardNumber = cardNumber;
        this.expiryDate = expiryDate;
        this.cvv = cvv;
    }

    // Empty constructor for Firebase
    public Card() {}

    // Getters and setters
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }
}
