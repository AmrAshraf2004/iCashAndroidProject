package com.example.icash;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class ResetPasswordActivity extends AppCompatActivity {

    // Declare UI components
    private EditText emailInputField;
    private Button resetPasswordButton, backToLoginButton;

    // Firebase Authentication instance
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.resetpasswordscreen); // Set the XML layout file for the activity

        // Initialize UI components
        emailInputField = findViewById(R.id.edit_email_address_reset_password);
        resetPasswordButton = findViewById(R.id.reset_password_button);
        backToLoginButton = findViewById(R.id.back_to_login_button);

        // Initialize Firebase Authentication
        auth = FirebaseAuth.getInstance();

        // Set up reset password button click listener
        resetPasswordButton.setOnClickListener(v -> handleResetPassword());

        // Set up back to login button click listener
        backToLoginButton.setOnClickListener(v -> {
            // Navigate back to LoginActivity
            Intent intent = new Intent(ResetPasswordActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }

    /**
     * Handles the reset password process.
     */
    private void handleResetPassword() {
        // Get the email input
        String email = emailInputField.getText().toString().trim();

        // Validate email
        if (TextUtils.isEmpty(email)) {
            emailInputField.setError("Email is required");
            return;
        }
        if (!isValidEmail(email)) { // Use regex to validate email
            emailInputField.setError("Enter a valid email address");
            return;
        }

        // Send password reset email
        auth.sendPasswordResetEmail(email)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(this, "Password reset email sent!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Failed to send reset email: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    /**
     * Validates the email using a regular expression.
     *
     */
    private boolean isValidEmail(String email) {
        String emailPattern = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        return email.matches(emailPattern);
    }
}
